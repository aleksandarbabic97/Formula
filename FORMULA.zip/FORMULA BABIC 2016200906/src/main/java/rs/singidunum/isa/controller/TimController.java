package rs.singidunum.isa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import rs.singidunum.isa.dao.TimRepository;
import rs.singidunum.isa.dto.TimDTO;
import rs.singidunum.isa.mapper.TimMapper;
import rs.singidunum.isa.model.Tim;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/timovi")
@CrossOrigin("*")
public class TimController {

    private final TimRepository timRepository;

    @Autowired
    public TimController(TimRepository timRepository) {
        this.timRepository = timRepository;
    }

    @PostMapping()
    public TimDTO dodajTim(@RequestBody @Valid TimDTO timDTO) {
        Tim tim = TimMapper.INSTANCE.toTim(timDTO);
        return TimMapper.INSTANCE.toTimDTO(timRepository.save(tim));
    }

    @PutMapping(value = "{id}")
    public TimDTO promeniTim(@PathVariable("id") Integer id, @RequestBody @Valid TimDTO timDTO) {
        if (timRepository.findById(id).isPresent()) {
            Tim tim = TimMapper.INSTANCE.toTim(timDTO);
            return TimMapper.INSTANCE.toTimDTO(timRepository.save(tim));
        }
        return null;
    }

    @GetMapping(value = "{id}")
    public TimDTO nadjiJedan(@PathVariable("id") Integer id) {
        return TimMapper.INSTANCE.toTimDTO(timRepository.findById(id).get());
    }

    @GetMapping()
    public List<TimDTO> nadjiSve() {
        return TimMapper.INSTANCE.toListDTO(timRepository.findAll());
    }

    @DeleteMapping(value = "/{id}")
    public void obrisiTim(@PathVariable("id") Integer id) {
        timRepository.deleteById(id);
    }

    @GetMapping(value = "/broj")
    public int brojTimova() {
        return timRepository.findAll().size();
    }
}






