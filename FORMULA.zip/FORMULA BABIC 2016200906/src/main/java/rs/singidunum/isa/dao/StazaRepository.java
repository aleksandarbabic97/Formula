package rs.singidunum.isa.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rs.singidunum.isa.model.Staza;

@Repository
public interface StazaRepository extends JpaRepository<Staza, Integer> {
}
