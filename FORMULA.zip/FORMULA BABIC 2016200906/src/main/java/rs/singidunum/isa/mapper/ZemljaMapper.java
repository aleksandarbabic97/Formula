package rs.singidunum.isa.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import rs.singidunum.isa.dto.ZemljaDTO;
import rs.singidunum.isa.model.Zemlja;
import rs.singidunum.isa.model.Zemlja;

import java.util.List;

@Mapper
public interface ZemljaMapper {

    ZemljaMapper INSTANCE = Mappers.getMapper(ZemljaMapper.class);
    
    ZemljaDTO toZemljaDTO(Zemlja zemlja);

    Zemlja toZemlja(ZemljaDTO userDTO);

    List<ZemljaDTO> toListDTO(List<Zemlja> zemljaList);

    List<Zemlja> toList(List<ZemljaDTO> zemljaDTOList);

}






