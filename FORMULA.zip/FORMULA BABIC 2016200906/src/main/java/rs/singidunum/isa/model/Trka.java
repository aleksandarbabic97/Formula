package rs.singidunum.isa.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Trka {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private LocalDate datum;
    private Integer krugova;
    private LocalTime vreme;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "VozacId", foreignKey = @ForeignKey(name = "trka_vozac_FK"))
    private Vozac vozac;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "stazaId", foreignKey = @ForeignKey(name = "trka_staza_FK"))
    private Staza staza;

    public Trka() {
    }

    public Trka(LocalDate datum, Integer krugova, LocalTime vreme, Vozac vozac, Staza staza) {
        this.datum = datum;
        this.krugova = krugova;
        this.vreme = vreme;
        this.vozac = vozac;
        this.staza = staza;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public Integer getKrugova() {
        return krugova;
    }

    public void setKrugova(Integer krugova) {
        this.krugova = krugova;
    }

    public LocalTime getVreme() {
        return vreme;
    }

    public void setVreme(LocalTime vreme) {
        this.vreme = vreme;
    }

    public Vozac getVozac() {
        return vozac;
    }

    public void setVozac(Vozac vozac) {
        this.vozac = vozac;
    }

    public Staza getStaza() {
        return staza;
    }

    public void setStaza(Staza staza) {
        this.staza = staza;
    }
}
