package rs.singidunum.isa.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import rs.singidunum.isa.dto.StazaDTO;
import rs.singidunum.isa.model.Staza;

import java.util.List;

@Mapper
public interface StazaMapper {

    StazaMapper INSTANCE = Mappers.getMapper(StazaMapper.class);

    @Mapping(source = "zemlja.naziv", target = "zemlja")
    StazaDTO toStazaDTO(Staza staza);

    @Mapping(target = "zemlja", ignore = true)
    Staza toStaza(StazaDTO userDTO);

    List<StazaDTO> toListDTO(List<Staza> stazaList);

    List<Staza> toList(List<StazaDTO> stazaDTOList);

}






