package rs.singidunum.isa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Formula1Application {

	public static void main(String[] args) {
		SpringApplication.run(Formula1Application.class, args);
	}

}
