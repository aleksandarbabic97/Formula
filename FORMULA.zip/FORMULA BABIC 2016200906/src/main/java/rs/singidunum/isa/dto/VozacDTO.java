package rs.singidunum.isa.dto;

public class VozacDTO {

    private Integer id;
    private String ime;
    private String prezime;
    private Integer godina;
    private String postaoProfi;
    private String zemlja;
    private String nazivTima;

    public VozacDTO() {
    }

    public VozacDTO(Integer id, String ime, String prezime, Integer godina, String postaoProfi, String zemlja, String nazivTima) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.godina = godina;
        this.postaoProfi = postaoProfi;
        this.zemlja = zemlja;
        this.nazivTima = nazivTima;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Integer getGodina() {
        return godina;
    }

    public void setGodina(Integer godina) {
        this.godina = godina;
    }

    public String getPostaoProfi() {
        return postaoProfi;
    }

    public void setPostaoProfi(String postaoProfi) {
        this.postaoProfi = postaoProfi;
    }

    public String getZemlja() {
        return zemlja;
    }

    public void setZemlja(String zemlja) {
        this.zemlja = zemlja;
    }

    public String getNazivTima() {
        return nazivTima;
    }

    public void setNazivTima(String nazivTima) {
        this.nazivTima = nazivTima;
    }
}
