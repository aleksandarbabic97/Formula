package rs.singidunum.isa.dto;

public class ZemljaDTO {

    private Integer id;
    private String naziv;
    private String kontinent;

    public ZemljaDTO() {
    }

    public ZemljaDTO(String naziv, String kontinent) {
        this.naziv = naziv;
        this.kontinent = kontinent;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getKontinent() {
        return kontinent;
    }

    public void setKontinent(String kontinent) {
        this.kontinent = kontinent;
    }
}
