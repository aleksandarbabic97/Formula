package rs.singidunum.isa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import rs.singidunum.isa.dao.VozacRepository;
import rs.singidunum.isa.dto.VozacDTO;
import rs.singidunum.isa.mapper.VozacMapper;
import rs.singidunum.isa.model.Vozac;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/vozaci")
@CrossOrigin("*")
public class VozacController {

    private final VozacRepository vozacRepository;

    @Autowired
    public VozacController(VozacRepository vozacRepository) {
        this.vozacRepository = vozacRepository;
    }

    @PostMapping()
    public VozacDTO dodajVozaca(@RequestBody @Valid VozacDTO vozacDTO) {
        Vozac vozac = VozacMapper.INSTANCE.toVozac(vozacDTO);
        return VozacMapper.INSTANCE.toVozacDTO(vozacRepository.save(vozac));
    }

    @PutMapping(value = "{id}")
    public VozacDTO promeniVozaca(@PathVariable("id") Integer id, @RequestBody @Valid VozacDTO vozacDTO) {
        if (vozacRepository.findById(id).isPresent()) {
            Vozac vozac = VozacMapper.INSTANCE.toVozac(vozacDTO);
            return VozacMapper.INSTANCE.toVozacDTO(vozacRepository.save(vozac));
        }
        return null;
    }

    @GetMapping(value = "{id}")
    public VozacDTO nadjiJednog(@PathVariable("id") Integer id) {
        return VozacMapper.INSTANCE.toVozacDTO(vozacRepository.findById(id).get());
    }

    @GetMapping()
    public List<VozacDTO> nadjiSve() {
        return VozacMapper.INSTANCE.toListDTO(vozacRepository.findAll());
    }

    @DeleteMapping(value = "/{id}")
    public void obrisiVozaca(@PathVariable("id") Integer id) {
        vozacRepository.deleteById(id);
    }

    @GetMapping(value = "/broj")
    public int brojVozaca() {
        return vozacRepository.findAll().size();
    }
}






