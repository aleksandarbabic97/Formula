package rs.singidunum.isa.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import rs.singidunum.isa.dto.TrkaDTO;
import rs.singidunum.isa.model.Trka;

import java.util.List;

@Mapper
public interface TrkaMapper {

    TrkaMapper INSTANCE = Mappers.getMapper(TrkaMapper.class);

    @Mapping(source = "staza.ime", target = "staza")
    @Mapping(source = "vozac.ime", target = "ime")
    @Mapping(source = "vozac.prezime", target = "prezime")
    TrkaDTO toTrkaDTO(Trka trka);

    @Mapping(target = "staza", ignore = true)
    @Mapping(target = "vozac", ignore = true)
    Trka toTrka(TrkaDTO userDTO);

    List<TrkaDTO> toListDTO(List<Trka> trkaList);

    List<Trka> toList(List<TrkaDTO> trkaDTOList);

}






