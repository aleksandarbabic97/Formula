package rs.singidunum.isa.dto;

public class TimDTO {

    private Integer id;
    private String imeTima;
    private String baza;
    private Integer brojTitula;
    private Double poeni;

    public TimDTO() {
    }

    public TimDTO(String imeTima, String baza, Integer brojTitula, Double poeni) {
        this.imeTima = imeTima;
        this.baza = baza;
        this.brojTitula = brojTitula;
        this.poeni = poeni;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getImeTima() {
        return imeTima;
    }

    public void setImeTima(String imeTima) {
        this.imeTima = imeTima;
    }

    public String getBaza() {
        return baza;
    }

    public void setBaza(String baza) {
        this.baza = baza;
    }

    public Integer getBrojTitula() {
        return brojTitula;
    }

    public void setBrojTitula(Integer brojTitula) {
        this.brojTitula = brojTitula;
    }

    public Double getPoeni() {
        return poeni;
    }

    public void setPoeni(Double poeni) {
        this.poeni = poeni;
    }
}



