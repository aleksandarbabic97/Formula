package rs.singidunum.isa.model;

import javax.persistence.*;

@Entity
public class Vozac {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String ime;
    private String prezime;
    private Integer godina;
    private String postaoProfi;

    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JoinColumn(name = "zemljaId", foreignKey = @ForeignKey(name = "vozac_zemlja_FK"))
    private Zemlja zemlja;

    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
    @JoinColumn(name = "timId", foreignKey = @ForeignKey(name = "vozac_tim_FK"))
    private Tim tim;

    public Vozac() {
    }

    public Vozac(String ime, String prezime, Integer godina, String postaoProfi, Zemlja zemlja, Tim tim) {
        this.ime = ime;
        this.prezime = prezime;
        this.godina = godina;
        this.postaoProfi = postaoProfi;
        this.zemlja = zemlja;
        this.tim = tim;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Integer getGodina() {
        return godina;
    }

    public void setGodina(Integer godina) {
        this.godina = godina;
    }

    public Zemlja getZemlja() {
        return zemlja;
    }

    public void setZemlja(Zemlja zemlja) {
        this.zemlja = zemlja;
    }

    public String getPostaoProfi() {
        return postaoProfi;
    }

    public void setPostaoProfi(String postaoProfi) {
        this.postaoProfi = postaoProfi;
    }

    public Tim getTim() {
        return tim;
    }

    public void setTim(Tim tim) {
        this.tim = tim;
    }
}
