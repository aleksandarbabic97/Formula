package rs.singidunum.isa.dto;

public class StazaDTO {

    private Integer id;
    private Integer okreta;
    private Integer duzina;
    private String ime;
    private String zemlja;

    public StazaDTO() {
    }

    public StazaDTO(Integer id, Integer okreta, Integer duzina, String ime, String zemlja) {
        this.id = id;
        this.okreta = okreta;
        this.duzina = duzina;
        this.ime = ime;
        this.zemlja = zemlja;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOkreta() {
        return okreta;
    }

    public void setOkreta(Integer okreta) {
        this.okreta = okreta;
    }

    public Integer getDuzina() {
        return duzina;
    }

    public void setDuzina(Integer duzina) {
        this.duzina = duzina;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getZemlja() {
        return zemlja;
    }

    public void setZemlja(String zemlja) {
        this.zemlja = zemlja;
    }
}
