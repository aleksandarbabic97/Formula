package rs.singidunum.isa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import rs.singidunum.isa.dao.StazaRepository;
import rs.singidunum.isa.dto.StazaDTO;
import rs.singidunum.isa.mapper.StazaMapper;
import rs.singidunum.isa.model.Staza;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/staze")
@CrossOrigin("*")
public class StazaController {

    private final StazaRepository stazaRepository;

    @Autowired
    public StazaController(StazaRepository stazaRepository) {
        this.stazaRepository = stazaRepository;
    }

    @PostMapping()
    public StazaDTO dodajStazu(@RequestBody @Valid StazaDTO stazaDTO) {
        Staza staza = StazaMapper.INSTANCE.toStaza(stazaDTO);
        return StazaMapper.INSTANCE.toStazaDTO(stazaRepository.save(staza));
    }

    @PutMapping(value = "{id}")
    public StazaDTO promeniStazu(@PathVariable("id") Integer id, @RequestBody @Valid StazaDTO stazaDTO) {
        if (stazaRepository.findById(id).isPresent()) {
            Staza staza = StazaMapper.INSTANCE.toStaza(stazaDTO);
            return StazaMapper.INSTANCE.toStazaDTO(stazaRepository.save(staza));
        }
        return null;
    }

    @GetMapping(value = "{id}")
    public StazaDTO nadjiJednu(@PathVariable("id") Integer id) {
        return StazaMapper.INSTANCE.toStazaDTO(stazaRepository.findById(id).get());
    }

    @GetMapping()
    public List<StazaDTO> nadjiSve() {
        return StazaMapper.INSTANCE.toListDTO(stazaRepository.findAll());
    }

    @DeleteMapping(value = "/{id}")
    public void obrisiStazu(@PathVariable("id") Integer id) {
        stazaRepository.deleteById(id);
    }

    @GetMapping(value = "/broj")
    public int brojStaza() {
        return stazaRepository.findAll().size();
    }
}






