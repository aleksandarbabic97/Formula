package rs.singidunum.isa.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import rs.singidunum.isa.dto.VozacDTO;
import rs.singidunum.isa.model.Vozac;

import java.util.List;

@Mapper
public interface VozacMapper {

    VozacMapper INSTANCE = Mappers.getMapper(VozacMapper.class);

    @Mapping(source = "zemlja.naziv", target = "zemlja")
    @Mapping(source = "tim.imeTima", target = "nazivTima")
    VozacDTO toVozacDTO(Vozac vozac);

    @Mapping(target = "zemlja", ignore = true)
    @Mapping(target = "tim", ignore = true)
    Vozac toVozac(VozacDTO userDTO);

    List<VozacDTO> toListDTO(List<Vozac> vozacList);

    List<Vozac> toList(List<VozacDTO> vozacDTOList);

}






