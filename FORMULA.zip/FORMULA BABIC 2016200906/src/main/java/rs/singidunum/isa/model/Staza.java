package rs.singidunum.isa.model;

import javax.persistence.*;

@Entity
public class Staza {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer okreta;
    private Integer duzina;
    private String ime;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
    @JoinColumn(name = "zemljaId", foreignKey = @ForeignKey(name = "staza_zemlja_FK"))
    private Zemlja zemlja;

    public Staza() {
    }

    public Staza(Integer okreta, Integer duzina, String ime, Zemlja zemlja) {
        this.okreta = okreta;
        this.duzina = duzina;
        this.ime = ime;
        this.zemlja = zemlja;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOkreta() {
        return okreta;
    }

    public void setOkreta(Integer okreta) {
        this.okreta = okreta;
    }

    public Integer getDuzina() {
        return duzina;
    }

    public void setDuzina(Integer duzina) {
        this.duzina = duzina;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public Zemlja getZemlja() {
        return zemlja;
    }

    public void setZemlja(Zemlja zemlja) {
        this.zemlja = zemlja;
    }
}
