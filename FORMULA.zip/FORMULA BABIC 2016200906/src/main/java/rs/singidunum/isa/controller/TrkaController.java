package rs.singidunum.isa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import rs.singidunum.isa.dao.TrkaRepository;
import rs.singidunum.isa.dto.TrkaDTO;
import rs.singidunum.isa.mapper.TrkaMapper;
import rs.singidunum.isa.model.Trka;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/trke")
@CrossOrigin("*")
public class TrkaController {

    private final TrkaRepository trkaRepository;

    @Autowired
    public TrkaController(TrkaRepository trkaRepository) {
        this.trkaRepository = trkaRepository;
    }

    @PostMapping()
    public TrkaDTO dodajTrka(@RequestBody @Valid TrkaDTO trkaDTO) {
        Trka trka = TrkaMapper.INSTANCE.toTrka(trkaDTO);
        return TrkaMapper.INSTANCE.toTrkaDTO(trkaRepository.save(trka));
    }

    @PutMapping(value = "{id}")
    public TrkaDTO promeniTrka(@PathVariable("id") Integer id, @RequestBody @Valid TrkaDTO trkaDTO) {
        if (trkaRepository.findById(id).isPresent()) {
            Trka trka = TrkaMapper.INSTANCE.toTrka(trkaDTO);
            return TrkaMapper.INSTANCE.toTrkaDTO(trkaRepository.save(trka));
        }
        return null;
    }

    @GetMapping(value = "{id}")
    public TrkaDTO nadjiJednu(@PathVariable("id") Integer id) {
        return TrkaMapper.INSTANCE.toTrkaDTO(trkaRepository.findById(id).get());
    }

    @GetMapping()
    public List<TrkaDTO> nadjiSve() {
        return TrkaMapper.INSTANCE.toListDTO(trkaRepository.findAll());
    }

    @DeleteMapping(value = "/{id}")
    public void obrisiTrku(@PathVariable("id") Integer id) {
        trkaRepository.deleteById(id);
    }

    @GetMapping(value = "/broj")
    public int brojTrka() {
        return trkaRepository.findAll().size();
    }
}






