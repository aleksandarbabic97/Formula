package rs.singidunum.isa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import rs.singidunum.isa.dao.ZemljaRepository;
import rs.singidunum.isa.dto.ZemljaDTO;
import rs.singidunum.isa.mapper.ZemljaMapper;
import rs.singidunum.isa.model.Zemlja;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/zemlje")
@CrossOrigin("*")
public class ZemljaController {

    private final ZemljaRepository zemljaRepository;

    @Autowired
    public ZemljaController(ZemljaRepository zemljaRepository) {
        this.zemljaRepository = zemljaRepository;
    }

    @PostMapping()
    public ZemljaDTO dodajZemlju(@RequestBody @Valid ZemljaDTO zemljaDTO) {
        Zemlja zemlja = ZemljaMapper.INSTANCE.toZemlja(zemljaDTO);
        return ZemljaMapper.INSTANCE.toZemljaDTO(zemljaRepository.save(zemlja));
    }

    @PutMapping(value = "{id}")
    public ZemljaDTO promeniZemlju(@PathVariable("id") Integer id, @RequestBody @Valid ZemljaDTO zemljaDTO) {
        if (zemljaRepository.findById(id).isPresent()) {
            Zemlja zemlja = ZemljaMapper.INSTANCE.toZemlja(zemljaDTO);
            return ZemljaMapper.INSTANCE.toZemljaDTO(zemljaRepository.save(zemlja));
        }
        return null;
    }

    @GetMapping(value = "{id}")
    public ZemljaDTO nadjiJednu(@PathVariable("id") Integer id) {
        return ZemljaMapper.INSTANCE.toZemljaDTO(zemljaRepository.findById(id).get());
    }

    @GetMapping()
    public List<ZemljaDTO> nadjiSve() {
        return ZemljaMapper.INSTANCE.toListDTO(zemljaRepository.findAll());
    }

    @DeleteMapping(value = "/{id}")
    public void obrisiZemlju(@PathVariable("id") Integer id) {
        zemljaRepository.deleteById(id);
    }

    @GetMapping(value = "/broj")
    public int brojZemlji() {
        return zemljaRepository.findAll().size();
    }

}






