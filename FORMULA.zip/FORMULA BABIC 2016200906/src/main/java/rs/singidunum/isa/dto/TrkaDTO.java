package rs.singidunum.isa.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class TrkaDTO {

    private Integer id;
    private LocalDate datum;
    private Integer krugova;
    private LocalTime vreme;
    private String ime;
    private String prezime;
    private String staza;

    public TrkaDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public Integer getKrugova() {
        return krugova;
    }

    public void setKrugova(Integer krugova) {
        this.krugova = krugova;
    }

    public LocalTime getVreme() {
        return vreme;
    }

    public void setVreme(LocalTime vreme) {
        this.vreme = vreme;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getStaza() {
        return staza;
    }

    public void setStaza(String staza) {
        this.staza = staza;
    }
}
