package rs.singidunum.isa.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rs.singidunum.isa.model.Vozac;

@Repository
public interface VozacRepository extends JpaRepository<Vozac, Integer> {
}
