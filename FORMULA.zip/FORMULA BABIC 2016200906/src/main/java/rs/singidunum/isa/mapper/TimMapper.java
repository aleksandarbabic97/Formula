package rs.singidunum.isa.mapper;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import rs.singidunum.isa.dto.TimDTO;
import rs.singidunum.isa.model.Tim;

import java.util.List;

@Mapper
public interface TimMapper {

    TimMapper INSTANCE = Mappers.getMapper(TimMapper.class);

    TimDTO toTimDTO(Tim tim);
    
    Tim toTim(TimDTO userDTO);

    List<TimDTO> toListDTO(List<Tim> timList);

    List<Tim> toList(List<TimDTO> timDTOList);

}






