import React, { Component } from 'react';
import { Button, ButtonGroup, Container, Table } from 'reactstrap';
import AppNavbar from '../../AppNavbar';
import { Link } from 'react-router-dom';

class PrikazTrke extends Component {

  constructor(props) {
    super(props);
    this.state = {trke: [], isLoading: true};
    this.remove = this.remove.bind(this);
  }

  componentDidMount() {
    this.setState({isLoading: true});

    fetch('/trke/')
      .then(response => response.json())
      .then(data => this.setState({trke: data, isLoading: false}));
  }

  async remove(id) {
    await fetch(`/trke/${id}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }).then(() => {
      let trke = [...this.state.trke].filter(i => i.id !== id);
      this.setState({trke: trke});
    });
  }

  render() {
    const {trke, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    const trkeList = trke.map(trka => {
      return <tr key={trka.id}>
        <td>{trka.datum}</td>
        <td>{trka.krugova}</td>
        <td>{trka.vreme}</td>
        <td>
          <ButtonGroup>
            <Button size="sm" color="primary" tag={Link} to={"/trke/" + trka.id}>Promeni</Button>
            <Button size="sm" color="danger" onClick={() => this.remove(trka.id)}>Obrisi</Button>
          </ButtonGroup>
        </td>
      </tr>
    });

    return (
      <div>
        <AppNavbar/>
        <Container fluid>
          <div className="float-right">
            <Button color="success" tag={Link} to="/trke/novi">Nova trka</Button>
          </div>
          <h3>trke</h3>
          <Table className="mt-4">
            <thead>
            <tr>
              <th width="30%">Datum</th>
              <th width="30%">Krugova</th>
              <th width="20%">Vreme</th>
              <th width="10%">Opcije</th>
            </tr>
            </thead>
            <tbody>
            {trkeList}
            </tbody>
          </Table>
        </Container>
      </div>
    );
  }
}

export default PrikazTrke;