import React, { Component } from 'react';
import { Button, ButtonGroup, Container, Table } from 'reactstrap';
import AppNavbar from '../../AppNavbar';
import { Link } from 'react-router-dom';

class PrikazVozaci extends Component {

  constructor(props) {
    super(props);
    this.state = {vozaci: [], isLoading: true};
    this.remove = this.remove.bind(this);
  }

  componentDidMount() {
    this.setState({isLoading: true});

    fetch('/vozaci/')
      .then(response => response.json())
      .then(data => this.setState({vozaci: data, isLoading: false}));
  }

  async remove(id) {
    await fetch(`/vozaci/${id}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }).then(() => {
      let vozaci = [...this.state.vozaci].filter(i => i.id !== id);
      this.setState({vozaci: vozaci});
    });
  }

  render() {
    const {vozaci, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    const vozaciList = vozaci.map(vozac => {
      return <tr key={vozac.id}>
        <td>{vozac.ime}</td>
        <td>{vozac.prezime}</td>
        <td>{vozac.godina}</td>
        <td>{vozac.postaoProfi}</td>
        <td>{vozac.zemlja}</td>
        <td>{vozac.nazivTima}</td>
        <td>
          <ButtonGroup>
            <Button size="sm" color="primary" tag={Link} to={"/vozaci/" + vozac.id}>Promeni</Button>
            <Button size="sm" color="danger" onClick={() => this.remove(vozac.id)}>Obrisi</Button>
          </ButtonGroup>
        </td>
      </tr>
    });

    return (
      <div>
        <AppNavbar/>
        <Container fluid>
          <div className="float-right">
            <Button color="success" tag={Link} to="/vozaci/novi">Novi vozac</Button>
          </div>
          <h3>vozaci</h3>
          <Table className="mt-4">
            <thead>
            <tr>
              <th width="30%">Ime</th>
              <th width="20%">Prezime</th>
              <th width="30%">Godina</th>
              <th width="20%">Postao Profi</th>
              <th width="20%">Zemlja</th>
              <th width="20%">Naziv tima</th>
              <th width="10%">Opcije</th>
            </tr>
            </thead>
            <tbody>
            {vozaciList}
            </tbody>
          </Table>
        </Container>
      </div>
    );
  }
}

export default PrikazVozaci;