import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import AppNavbar from '../../AppNavbar';

class PromenaVozaci extends Component {

  emptyItem = {
    ime: '',
    prezime: '',
    godina: '',
    postaoProfi: '',
    zemlja: '',
    nazivTima: ''
  };

  constructor(props) {
    super(props);
    this.state = {
      item: this.emptyItem
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  async componentDidMount() {
    if (this.props.match.params.id !== 'nov') {
      const group = await (await fetch(`/vozaci/${this.props.match.params.id}`)).json();
      this.setState({item: group});
    }
  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    let item = {...this.state.item};
    item[name] = value;
    this.setState({item});
  }

  async handleSubmit(event) {
    event.preventDefault();
    const {item} = this.state;

    await fetch('/vozaci' + (item.id ? '/' + item.id : '') , {
      method: (item.id) ? 'PUT' : 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(item),
    });
    this.props.history.push('/vozaci');
  }

  render() {
    const {item} = this.state;
    const title = <h2>{item.id ? 'Promeni Vozaca' : 'Novi Vozac'}</h2>;

    return <div>
      <AppNavbar/>
      <Container>
        {title}
        <Form onSubmit={this.handleSubmit}>
          <FormGroup>
            <Label for="ime">Ime</Label>
            <Input type="text" name="ime" id="ime" value={item.ime || ''}
                   onChange={this.handleChange} autoComplete="ime"/>
          </FormGroup>
          <FormGroup>
            <Label for="prezime">Prezime</Label>
            <Input type="text" name="prezime" id="prezime" value={item.prezime || ''}
                   onChange={this.handleChange} autoComplete="prezime"/>
          </FormGroup>
          <FormGroup>
            <Label for="godina">Godina</Label>
            <Input type="text" name="godina" id="godina" value={item.godina || ''}
                   onChange={this.handleChange} autoComplete="godina"/>
          </FormGroup>
          <FormGroup>
            <Label for="postaoProfi">Postao profi</Label>
            <Input type="text" name="postaoProfi" id="postaoProfi" value={item.postaoProfi || ''}
                   onChange={this.handleChange} autoComplete="postaoProfi"/>
          </FormGroup>
          <FormGroup>
            <Button color="primary" type="submit">Sacuvaj</Button>{' '}
            <Button color="secondary" tag={Link} to="/vozaci">Otkazi</Button>
          </FormGroup>
        </Form>
      </Container>
    </div>
  }
}

export default withRouter(PromenaVozaci);