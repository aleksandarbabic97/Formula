import React, { Component } from 'react';
import { Button, ButtonGroup, Container, Table } from 'reactstrap';
import AppNavbar from '../../AppNavbar';
import { Link } from 'react-router-dom';

class PrikazStaze extends Component {

  constructor(props) {
    super(props);
    this.state = {staze: [], isLoading: true};
    this.remove = this.remove.bind(this);
  }

  componentDidMount() {
    this.setState({isLoading: true});

    fetch('/staze/')
      .then(response => response.json())
      .then(data => this.setState({staze: data, isLoading: false}));
  }

  async remove(id) {
    await fetch(`/staze/${id}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }).then(() => {
      let staze = [...this.state.staze].filter(i => i.id !== id);
      this.setState({staze: staze});
    });
  }

  render() {
    const {staze, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    const stazeList = staze.map(staza => {
      return <tr key={staza.id}>
        <td>{staza.okreta}</td>
        <td>{staza.duzina}</td>
        <td>{staza.ime}</td>
        <td>{staza.zemlja}</td>
        <td>
          <ButtonGroup>
            <Button size="sm" color="primary" tag={Link} to={"/staze/" + staza.id}>Promeni</Button>
            <Button size="sm" color="danger" onClick={() => this.remove(staza.id)}>Obrisi</Button>
          </ButtonGroup>
        </td>
      </tr>
    });

    return (
      <div>
        <AppNavbar/>
        <Container fluid>
          <div className="float-right">
            <Button color="success" tag={Link} to="/staze/novi">Nova Staza</Button>
          </div>
          <h3>staze</h3>
          <Table className="mt-4">
            <thead>
            <tr>
              <th width="30%">Okreta</th>
              <th width="20%">Duzina</th>
              <th width="30%">Ime</th>
              <th width="20%">Zemlja</th>
              <th width="10%">Opcije</th>
            </tr>
            </thead>
            <tbody>
            {stazeList}
            </tbody>
          </Table>
        </Container>
      </div>
    );
  }
}

export default PrikazStaze;