import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
import AppNavbar from '../../AppNavbar';

class PromenaTimovi extends Component {

  emptyItem = {
    imeTima: '',
    baza: '',
    brojTitula: '',
    poeni: ''
  };

  constructor(props) {
    super(props);
    this.state = {
      item: this.emptyItem
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  async componentDidMount() {
    if (this.props.match.params.id !== 'nov') {
      const group = await (await fetch(`/timovi/${this.props.match.params.id}`)).json();
      this.setState({item: group});
    }
  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    let item = {...this.state.item};
    item[name] = value;
    this.setState({item});
  }

  async handleSubmit(event) {
    event.preventDefault();
    const {item} = this.state;

    await fetch('/timovi' + (item.id ? '/' + item.id : '') , {
      method: (item.id) ? 'PUT' : 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(item),
    });
    this.props.history.push('/timovi');
  }

  render() {
    const {item} = this.state;
    const title = <h2>{item.id ? 'Promeni Tim' : 'Novi Tim'}</h2>;

    return <div>
      <AppNavbar/>
      <Container>
        {title}
        <Form onSubmit={this.handleSubmit}>
          <FormGroup>
            <Label for="imeTima">Tim Ime</Label>
            <Input type="text" name="imeTima" id="imeTima" value={item.imeTima || ''}
                   onChange={this.handleChange} autoComplete="imeTima"/>
          </FormGroup>
          <FormGroup>
            <Label for="brojTitula">Broj Titula</Label>
            <Input type="text" name="brojTitula" id="brojTitula" value={item.brojTitula || ''}
                   onChange={this.handleChange} autoComplete="brojTitula"/>
          </FormGroup>
          <FormGroup>
            <Label for="baza">Baza</Label>
            <Input type="text" name="baza" id="baza" value={item.baza || ''}
                   onChange={this.handleChange} autoComplete="baza"/>
          </FormGroup>
          <FormGroup>
            <Label for="poeni">Poeni</Label>
            <Input type="text" name="poeni" id="poeni" value={item.poeni || ''}
                   onChange={this.handleChange} autoComplete="poeni"/>
          </FormGroup>
          <FormGroup>
            <Button color="primary" type="submit">Sacuvaj</Button>{' '}
            <Button color="secondary" tag={Link} to="/timovi">Otkazi</Button>
          </FormGroup>
        </Form>
      </Container>
    </div>
  }
}

export default withRouter(PromenaTimovi);