import React, { Component } from 'react';
import '../App.css';
import AppNavbar from '../AppNavbar';
import { Link } from 'react-router-dom';
import { Button, Container } from 'reactstrap';

class Home extends Component {
  render() {
    return (
      <div>
        <AppNavbar/>
        <Container fluid>
          <Button color="secondary" tag={Link} to="/timovi">Formula 1 Timovi</Button>&nbsp;
          <Button color="secondary" tag={Link} to="/vozaci">Formula 1 Vozaci</Button>&nbsp;
          <Button color="secondary" tag={Link} to="/staze">Formula 1 Staze</Button>&nbsp;
          <Button color="secondary" tag={Link} to="/trke">Formula 1 Trke</Button>&nbsp;
          <Button color="secondary" tag={Link} to="/zemlje">Zemlje</Button>
        </Container>
      </div>
    );
  }
}

export default Home;