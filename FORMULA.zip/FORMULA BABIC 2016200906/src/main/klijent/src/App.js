import React, { Component } from 'react';
import './App.css';
import Home from './views/Home';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import PrikazTimovi from './views/timovi/PrikazTimovi';
import PromenaTimovi from './views/timovi/PromenaTimovi';
import PrikazVozaci from './views/vozaci/PrikazVozaci';
import PromenaVozaci from './views/vozaci/PromenaVozaci';
import PrikazZemlje from './views/zemlje/PrikazZemlje';
import PromenaZemlje from './views/zemlje/PromenaZemlje';
import PrikazStaze from './views/staze/PrikazStaze';
import PromenaStaze from './views/staze/PromenaStaze';
import PrikazTrke from './views/trke/PrikazTrke';
import PromenaTrke from './views/trke/PromenaTrke';

class App extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path='/' exact={true} component={Home}/>
          <Route path='/timovi' exact={true} component={PrikazTimovi}/>
          <Route path='/timovi/:id' component={PromenaTimovi}/>
          <Route path='/vozaci' exact={true} component={PrikazVozaci}/>
          <Route path='/vozaci/:id' component={PromenaVozaci}/>
          <Route path='/trke' exact={true} component={PrikazTrke}/>
          <Route path='/trke/:id' component={PromenaTrke}/>
          <Route path='/staze' exact={true} component={PrikazStaze}/>
          <Route path='/staze/:id' component={PromenaStaze}/>
          <Route path='/zemlje' exact={true} component={PrikazZemlje}/>
          <Route path='/zemlje/:id' component={PromenaZemlje}/>
          
        </Switch>
      </Router>
    )
  }
}

export default App;