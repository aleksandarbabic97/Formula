# create database formula;

INSERT INTO tim (id, baza, broj_titula, ime_tima, poeni)
VALUES (1, 'Berlin', 10, 'Mercedes', 200),
       (2, 'Pariz', 12, 'McLaren', 180),
       (3, 'Rim', 15, 'Ferrari', 220);


INSERT INTO zemlja (id, kontinent, naziv)
VALUES (1, 'Evropa', 'Engleska'),
       (2, 'Evropa', 'Monako'),
       (3, 'Evropa', 'Finska'),
       (4, 'Australija', 'Australija'),
       (5, 'Evropa', 'Holandija'),
       (6, 'Evropa', 'Nemacka');


INSERT INTO vozac (id, ime, prezime, godina, zemlja_id, postao_profi, tim_id)
VALUES (1, 'Lewis', 'Hamilton', 32, 1, '2003', 1),
       (2, 'Charles', 'Leclerc', 33, 2, '2001', 1),
       (3, 'Lando', 'Norris', 32, 1, '1998', 2),
       (4, 'Kimi', 'Raikkonen', 25, 3, '2011', 2),
       (5, 'Daniel', 'Ricciardo', 32, 4, '2003', 3),
       (6, 'Max', 'Verstappen', 20, 5, '2006', 3),
       (7, 'Sebastian', 'Vettel', 29, 6, '2007', 3);

INSERT INTO staza (id, ime, duzina, okreta, zemlja_id)
VALUES (1, 'England A', 112, 54, 1),
       (2, 'France Open ALL',145, 50, 1),
       (3, 'Northy', 178, 52, 3),
       (4, 'Australia 1', 190, 50, 4),
       (5, 'Holland', 112, 55, 5);

INSERT INTO trka (id, datum, krugova, vreme, staza_id, vozac_id)
VALUES (1, DATE('2020-06-15'), 54, TIME('1:30:10'),1,1),
       (2, DATE('2020-06-15'), 54, TIME('1:20:10'),1,2),
       (3, DATE('2020-06-15'), 54, TIME('1:50:10'),1,3),
       (4, DATE('2020-06-15'), 54, TIME('1:38:10'),1,4),
       (5, DATE('2020-06-11'), 54, TIME('1:11:10'),2,1),
       (6, DATE('2020-06-11'), 54, TIME('1:18:10'),2,3),
       (7, DATE('2020-06-11'), 56, TIME('1:28:10'),2,5),
       (8, DATE('2020-06-11'), 55, TIME('1:38:10'),2,6),
       (9, DATE('2020-06-11'), 53, TIME('1:40:10'),2,7);
